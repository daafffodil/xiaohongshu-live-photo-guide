// GIF87a/89a decoder, including local palettes, interlacing and disposal.
(function(root){
function decode(buffer){
 const b=new Uint8Array(buffer);let p=0;
 const byte=()=>{if(p>=b.length)throw Error('GIF 文件不完整');return b[p++];};
 const word=()=>byte()|byte()<<8;
 const signature=String.fromCharCode(...b.slice(0,6));if(!/^GIF8[79]a$/.test(signature))throw Error('请选择有效的GIF');p=6;
 const width=word(),height=word();if(!width||!height||width*height>16000000)throw Error('GIF 尺寸过大');
 const packed=byte(),background=byte();byte();
 const palette=n=>{const a=[];for(let i=0;i<n;i++)a.push([byte(),byte(),byte()]);return a;};
 const global=packed&128?palette(1<<((packed&7)+1)):null;
 const blocks=()=>{const a=[];let n;while((n=byte()))for(let i=0;i<n;i++)a.push(byte());return new Uint8Array(a);};
 const frames=[];let delay=100,disposal=0,transparent=-1,duration=0,totalPixels=0;
 while(p<b.length){const marker=byte();if(marker===59)break;
  if(marker===33){const label=byte();if(label===249){if(byte()!==4)throw Error('GIF 控制块无效');const f=byte();delay=Math.max(20,word()*10||100);const t=byte();transparent=f&1?t:-1;disposal=(f>>2)&7;if(byte()!==0)throw Error('GIF 控制块无效');}else blocks();continue;}
  if(marker!==44)throw Error('GIF 图像块无效');
  const x=word(),y=word(),w=word(),h=word(),flags=byte();totalPixels+=w*h;
  if(!w||!h||x+w>width||y+h>height||totalPixels>80000000)throw Error('GIF 过大，请使用较短的文件');
  const colors=flags&128?palette(1<<((flags&7)+1)):global;if(!colors)throw Error('GIF 缺少颜色表');
  const minimum=byte();if(minimum<2||minimum>8)throw Error('GIF 编码无效');const data=blocks(),clear=1<<minimum,end=clear+1;
  let dict,size,bit=0,old=null;const reset=()=>{dict=Array.from({length:clear},(_,i)=>[i]);dict.push([],[]);size=minimum+1;old=null;};reset();
  const indices=new Uint8Array(w*h);let at=0;
  while(bit+size<=data.length*8){let code=0;for(let i=0;i<size;i++,bit++)code|=((data[bit>>3]>>(bit&7))&1)<<i;
   if(code===clear){reset();continue;}if(code===end)break;
   const entry=dict[code]||(code===dict.length&&old?[...old,old[0]]:null);if(!entry||at+entry.length>indices.length)throw Error('GIF 数据无效');indices.set(entry,at);at+=entry.length;
   if(old&&dict.length<4096){dict.push([...old,entry[0]]);if(dict.length===(1<<size)&&size<12)size++;}old=entry;
  }
  if(at!==indices.length)throw Error('GIF 帧不完整');
  let rows=Array.from({length:h},(_,i)=>i);if(flags&64){rows=[];for(const [start,step] of [[0,8],[4,8],[2,4],[1,2]])for(let r=start;r<h;r+=step)rows.push(r);}
  const rgba=new Uint8ClampedArray(w*h*4);for(let r=0;r<h;r++)for(let c=0;c<w;c++){const idx=indices[r*w+c],o=(rows[r]*w+c)*4,col=colors[idx];if(!col)throw Error('GIF 颜色无效');rgba.set([...col,idx===transparent?0:255],o);}
  frames.push({x,y,w,h,rgba,delay,disposal,transparent,start:duration});duration+=delay;delay=100;disposal=0;transparent=-1;
 }
 if(!frames.length)throw Error('GIF 没有画面');return {width,height,frames,duration,background:(global && global[background])||[0,0,0]};
}
root.SourGif={decode};
})(typeof window==='undefined'?globalThis:window);
