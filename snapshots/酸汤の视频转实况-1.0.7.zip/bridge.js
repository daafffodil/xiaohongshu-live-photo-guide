// The SDK documents both callbacks and Promises. Handle either, with bounded preparation.
let sourFileSequence=0;
function bridgeCall(sdk,name,options,label,timeout=15000){
 return new Promise((resolve,reject)=>{
  let finished=false;
  const timer=setTimeout(()=>finish(Error(label+'超时，请重新打开小工具')),timeout);
  function finish(error,value){if(finished)return;finished=true;clearTimeout(timer);if(error)reject(error);else resolve(value);}
  try{const result=sdk[name](Object.assign({},options,{success:value=>finish(null,value),fail:error=>finish(error)}));if(result&&typeof result.then==='function')result.then(value=>finish(null,value),error=>finish(error));}
  catch(error){finish(error);}
 });
}
function miniTool() { return window.xhs && window.xhs.miniTool; }
async function buildVersion() {
  const xhs = window.xhs, launch = xhs && xhs.launchOptions;
  let version = Number(launch && launch.miniToolEnv && launch.miniToolEnv.buildVersion) || 0;
  const sdk = miniTool();
  if (!version && sdk && typeof sdk.getLaunchOptions === 'function') {
    try { const result = await bridgeCall(sdk,'getLaunchOptions',{},'客户端检查'); version = Number(result && result.miniToolEnv && result.miniToolEnv.buildVersion) || 0; } catch (_) {}
  }
  return Math.floor(version / 1000);
}
function readBlob(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();let finished=false;
    const timer=setTimeout(()=>{finish(new Error('视频读取超时，请重新选择'));try{reader.abort();}catch(_){}},15000);
    function finish(error,value){if(finished)return;finished=true;clearTimeout(timer);reader.onload=reader.onerror=reader.onabort=null;error?reject(error):resolve(value);}
    reader.onload=()=>finish(null,reader.result);
    reader.onerror=()=>finish(new Error('素材读取失败，请重新选择'));
    reader.onabort=()=>finish(new Error('素材读取已中断，请重新选择'));
    try{reader.readAsDataURL(blob);}catch(error){finish(error);}
  });
}
function mediaError(error, action) {
  const message = String(error && (error.errMsg || error.message) || '');
  console.error(action, error);
  if (/cancel/i.test(message)) return '已取消';
  if (/permission|authorize|authorization|denied|权限|未授权/i.test(message)) return '请在系统设置中允许小红书访问相册';
  const code=error&&error.errCode!=null?'（'+String(error.errCode).slice(0,30)+'）':'';
  const detail=message.replace(/data:[^\s]+/g,'[素材]').replace(/(?:https?:|xhsfile:|file:)[^\s]+/g,'[路径]').slice(0,180);
  return action+'失败'+code+(detail?'：'+detail:'，请重试');
}
async function writeVideoFile(sdk, blob, extension='mp4') {
  const useChunks = (blob.size > 4*1024*1024 || extension !== 'mp4') && await buildVersion() >= 9490 && ['getFileStorageInfo', 'getLaunchOptions', 'writeFile', 'appendFile'].every(name => typeof sdk[name] === 'function');
  if(!useChunks && extension !== 'mp4')throw Error('当前客户端无法读取此视频，请选择MP4');
  if (!useChunks) return bridgeCall(sdk,'writeTempFile',{data:await readBlob(blob)},'视频写入');
  const options = await bridgeCall(sdk,'getLaunchOptions',{},'读取目录'), root = options && options.miniToolEnv && options.miniToolEnv.userDataPath;
  if (!root) throw new Error('missing storage path');
  const info = await bridgeCall(sdk,'getFileStorageInfo',{},'读取存储信息');
  const chunkSize = Math.floor(Number(info.writeChunkMaxBytes));
  if (!(chunkSize > 0)) throw new Error('invalid chunk size');
  const filePath = root + '/sour-live-'+Date.now()+'-'+(++sourFileSequence)+'.'+extension;
  for (let offset = 0; offset < blob.size; offset += chunkSize) {
    const chunk = blob.slice(offset, Math.min(blob.size, offset + chunkSize));
    const data = (await readBlob(chunk)).split(',')[1];
    const result = await bridgeCall(sdk,offset?'appendFile':'writeFile',{filePath,data,encoding:'base64'},'视频写入');
    if (result && typeof result.writtenBytes === 'number' && result.writtenBytes !== chunk.size) throw new Error('incomplete write');
  }
  if (typeof sdk.statFile === 'function') {
    const stat = await bridgeCall(sdk,'statFile',{filePath},'视频校验');
    if (stat.size !== blob.size) throw new Error('incomplete video');
  }
  return { filePath, persistent:true };
}

// Ported from the shipped shamsham 1.0.7 artifact confirmed by the user.
function verifyLiveMedia(media) {
  return new Promise((resolve,reject)=>{
    const video=document.createElement('video');let done=false;
    const timer=setTimeout(()=>finish(new Error('视频读取超时，请重新生成')),15000);
    function finish(error){
      if(done)return;done=true;clearTimeout(timer);
      video.onloadeddata=null;video.onerror=null;video.removeAttribute('src');video.load();
      error?reject(error):resolve();
    }
    video.muted=true;video.playsInline=true;video.preload='auto';
    video.onloadeddata=()=>{
      if(!(video.videoWidth>0&&video.videoHeight>0&&Number.isFinite(video.duration)&&video.duration>0))return finish(new Error('视频内容无效，请重新生成'));
      finish();
    };
    video.onerror=()=>finish(new Error('小红书无法读取生成的视频，请重新生成'));
    video.src=media.video_url;video.load();
  });
}
let publishMediaField='live_photo_sources',publishPageType='slides_edit';
function openPreparedPublisher(sdk,media){
  if(!media||typeof media.url!=='string'||!media.url||typeof media.video_url!=='string'||!media.video_url)throw Error('发布素材路径无效，请重新生成');
  const alternate=publishMediaField==='live_photo_resources'?'live_photo_sources':'live_photo_resources';
  const otherPage=publishPageType==='slides_edit'?'photo_publish':'slides_edit';
  const routes=[[publishPageType,publishMediaField],[publishPageType,alternate],[otherPage,publishMediaField],[otherPage,alternate]];
  function attempt(index){
    const pageType=routes[index][0],field=routes[index][1],resources={};
    resources[field]=[{url:media.url,video_url:media.video_url}];
    function rejected(error){
      const message=String(error&&(error.errMsg||error.message)||'');
      const rejectedMedia=/media[_\s]?info/i.test(message)||/slides[\s_]+resources?[\s_]+too[\s_]+few/i.test(message);
      // Match 1.0.7: only an explicit local media-parameter rejection can
      // try another route. Cancellation, pending editors and unknown errors stop.
      if(index+1>=routes.length||Number(error&&error.errCode)!==10001||!/invalid\s*param/i.test(message)||!rejectedMedia)throw error;
      return attempt(index+1);
    }
    let result;
    try{result=sdk.postNote({pageType,mediaInfo:resources});}catch(error){return rejected(error);}
    return Promise.resolve(result).then(value=>{publishMediaField=field;publishPageType=pageType;return value;},rejected);
  }
  return attempt(0);
}

window.SourBridge = {
  errorMessage:mediaError,
  available() { const sdk = miniTool(); return !!(sdk && typeof sdk.postNote === 'function' && typeof sdk.writeTempFile === 'function'); },
  async validate() { const v = await buildVersion(); if (v && v < 9430) throw Error('请将小红书更新到 9.43 或以上版本'); },
  async importVideo(file){
    const extension=/quicktime/i.test(file.type)||/\.mov$/i.test(file.name||'')?'mov':'mp4';
    const blob=!file.type&&typeof file.slice==='function'?file.slice(0,file.size,extension==='mov'?'video/quicktime':'video/mp4'):file;
    const media=await writeVideoFile(miniTool(),blob,extension);
    if(!media||!media.filePath)throw Error('视频读取失败，请重新选择');
    return media;
  },
  releaseVideo(media){
    const sdk=miniTool();
    if(media&&media.persistent&&sdk&&typeof sdk.unlink==='function')bridgeCall(sdk,'unlink',{filePath:media.filePath},'清理视频').catch(()=>{});
  },
  async prepare(cover,video,onStage){
    const sdk=miniTool();
    if(!this.available())throw Error('当前环境不支持发布，请在小红书内打开');
    if(onStage)onStage('正在准备封面');
    const image=await bridgeCall(sdk,'writeTempFile',{data:cover},'封面写入');
    if(!image||!image.filePath)throw Error('封面写入失败');
    if(onStage)onStage('正在准备发布素材');
    // A publisher needs the opaque path returned by writeTempFile, even when
    // the generated MP4 is larger than the old 4 MiB branching threshold.
    // Keep chunked source-file importing separate from publishing output.
    const movie=await bridgeCall(sdk,'writeTempFile',{data:await readBlob(video)},'视频写入',30000);
    if(!movie||!movie.filePath)throw Error('视频写入失败');
    const media={url:image.filePath,video_url:movie.filePath};
    if(onStage)onStage('正在检查视频');
    await verifyLiveMedia(media);
    return media;
  },
  publishPrepared(media){
    const sdk=miniTool();
    if(!this.available())throw Error('当前环境不支持发布，请在小红书内打开');
    if(!media||!media.url||!media.video_url)throw Error('请先生成发布素材');
    // Do not time out publication: the user may remain on the editor for minutes.
    return openPreparedPublisher(sdk,media);
  },
  publishVideoPrepared(media){
    const sdk=miniTool();
    if(!this.available())throw Error('当前环境不支持发布，请在小红书内打开');
    if(!media||typeof media.url!=='string'||!media.url||typeof media.video_url!=='string'||!media.video_url)throw Error('请先生成发布素材');
    return sdk.postNote({pageType:'video_publish',mediaInfo:{video_resources:{video_url:media.video_url,cover_url:media.url}}});
  },
  async publish(cover,video){return this.publishPrepared(await this.prepare(cover,video));}
};
