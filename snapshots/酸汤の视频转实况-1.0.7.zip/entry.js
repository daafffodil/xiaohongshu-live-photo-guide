// Keep the primary action responsive even when media initialization fails.
(function () {
  var buttons = [document.querySelector('#publish'),document.querySelector('#publish-video')].filter(Boolean);
  var message = document.querySelector('#status');
  var handler = null, pending = false;
  function show(text) {
    message.textContent = text;
    message.scrollIntoView({ block: 'nearest' });
  }
  buttons.forEach(function(button){button.addEventListener('click', function () {
    if (pending) return;
    if (!handler) { show('发布组件未加载，请重新打开小工具'); return; }
    pending = true;
    buttons.forEach(function(item){item.disabled=true;});
    button.setAttribute('aria-busy', 'true');
    var result;
    // Invoke synchronously so a prepared postNote keeps this user's gesture.
    try { result = handler(button.id==='publish-video'?'video':'live'); } catch (error) { result = Promise.reject(error); }
    Promise.resolve(result).catch(function (error) {
      show(error && (error.message || error.errMsg) || '发布未能启动，请重新打开小工具');
    }).then(function () {
      pending = false;
      buttons.forEach(function(item){item.disabled=false;});
      button.setAttribute('aria-busy', 'false');
    });
  });});
  window.addEventListener('error', function () {
    if (!handler) show('页面加载失败，请重新打开小工具');
  });
  window.SourPublishEntry = { connect: function (callback) { handler = callback; } };
}());
