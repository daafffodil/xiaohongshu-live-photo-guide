// Size the preview from the actual viewport and controls, including safe areas.
(function(){
 const root=document.documentElement,key='sour-header-'+window.innerWidth+'x'+window.innerHeight;
 let pending=false,observed=false;
 function number(value){return parseFloat(value)||0;}
 function set(name,value){if(root.style.getPropertyValue(name)!==value)root.style.setProperty(name,value);}
 function outerHeight(element){
  if(!element)return 0;const style=getComputedStyle(element);
  if(style.display==='none')return 0;
  return element.getBoundingClientRect().height+number(style.marginTop)+number(style.marginBottom);
 }
 function measure(){
  pending=false;
  const main=document.querySelector('main'),drop=document.querySelector('#drop');
  if(!main||!drop)return;
  const viewport=window.visualViewport;
  const height=Math.floor(viewport?Math.min(window.innerHeight,viewport.height):window.innerHeight);
  set('--viewport-height',height+'px');
  const style=getComputedStyle(main),contentWidth=main.clientWidth-number(style.paddingLeft)-number(style.paddingRight);
  const ratio=number(getComputedStyle(root).getPropertyValue('--frame-scale'))||.75;
  const controls=['header','.choose','.ratios','#trim','#status','footer','#version'];
  // Footer auto margin fills unused space; it is not part of its minimum size.
  let occupied=number(style.paddingTop)+number(style.paddingBottom)+2;
  controls.forEach(selector=>{
   const element=document.querySelector(selector);if(!element)return;
   if(selector==='footer')occupied+=element.getBoundingClientRect().height;
   else occupied+=outerHeight(element);
  });
  const border=4,available=Math.max(144,height-occupied-border);
  const width=Math.floor(Math.min(360,contentWidth,available*ratio+border));
  set('--media-width',Math.max(0,width)+'px');
  set('--media-height',((width-border)/ratio+border)+'px');
 }
 function schedule(){if(!pending){pending=true;requestAnimationFrame(measure);}}
 function observe(){
  if(observed)return;observed=true;
  if(typeof ResizeObserver==='function'){
   const observer=new ResizeObserver(schedule);
   ['header','.choose','.ratios','#trim','#status','footer','#version'].forEach(selector=>{const e=document.querySelector(selector);if(e)observer.observe(e);});
  }else if(typeof MutationObserver==='function'){
   const status=document.querySelector('#status');if(status)new MutationObserver(schedule).observe(status,{childList:true,subtree:true,characterData:true});
  }
  schedule();
 }
 window.SourLayout={fit:schedule};
 try{const saved=Number(sessionStorage.getItem(key));if(saved>=18&&saved<200)set('--header-top-space',saved+'px');}catch(e){}
 async function fitHeader(){
  const sdk=window.xhs&&window.xhs.miniTool;if(!sdk||typeof sdk.getWindowInfo!=='function'){schedule();return;}
  try{const info=await sdk.getWindowInfo();let top=Number(info.safeArea&&info.safeArea.top)||0;const buttons=info.menuButtons||{};['back','me','share'].forEach(name=>{if(buttons[name])top=Math.max(top,Number(buttons[name].bottom)||0);});const space=Math.ceil(top+8);set('--header-top-space',space+'px');try{sessionStorage.setItem('sour-header-'+window.innerWidth+'x'+window.innerHeight,String(space));}catch(e){}}catch(e){}
  schedule();
 }
 fitHeader();document.addEventListener('DOMContentLoaded',()=>{observe();fitHeader();},{once:true});
 window.addEventListener('resize',()=>{schedule();fitHeader();});
 if(window.visualViewport)window.visualViewport.addEventListener('resize',schedule);
})();
