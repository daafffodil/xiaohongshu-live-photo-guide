// Capability-detected AVC compression. No change to the shared software encoder.
(function(root){
'use strict';
  const bytes = (...values) => new Uint8Array(values);
  function concat(parts) { const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0)); let at = 0; parts.forEach(p => { out.set(p, at); at += p.length; }); return out; }
  const u16 = n => bytes(n >>> 8, n & 255);
  const u32 = n => bytes(n >>> 24, n >>> 16 & 255, n >>> 8 & 255, n & 255);
  const ascii = text => new Uint8Array(Array.from(text, c => c.charCodeAt(0)));
  const zero = n => new Uint8Array(n);
  const box = (type, ...parts) => { const body = concat(parts); return concat([u32(body.length + 8), ascii(type), body]); };
  const full = (type, version, flags, ...parts) => box(type, bytes(version, flags >>> 16, flags >>> 8 & 255, flags & 255), ...parts);
  const matrix = concat([u32(65536),u32(0),u32(0),u32(0),u32(65536),u32(0),u32(0),u32(0),u32(0x40000000)]);
  function mux(samples, width, height, fps, description) {
    const count = samples.length, duration = count * 1000 / fps;
    const ftyp = box('ftyp', ascii('isom'), u32(512), ascii('isomiso2avc1mp41'));
    const mdat = box('mdat', ...samples.map(s => s.data));
    const avcC = box('avcC', description);
    const avc1 = box('avc1', zero(6), u16(1), zero(16), u16(width), u16(height), u32(0x480000), u32(0x480000), zero(4), u16(1), zero(32), u16(24), u16(0xffff), avcC);
    const keys=samples.map((s,i)=>s.key?i+1:0).filter(Boolean);
    const sync=full('stss',0,0,u32(keys.length),...keys.map(u32));
    const stbl = box('stbl', full('stsd',0,0,u32(1),avc1), full('stts',0,0,u32(1),u32(count),u32(1000)), full('stsc',0,0,u32(1),u32(1),u32(count),u32(1)), full('stsz',0,0,u32(0),u32(count),...samples.map(s => u32(s.data.length))), full('stco',0,0,u32(1),u32(ftyp.length+8)), sync);
    const dinf = box('dinf', full('dref',0,0,u32(1),full('url ',0,1)));
    const minf = box('minf', full('vmhd',0,1,zero(8)), dinf, stbl);
    const mdia = box('mdia', full('mdhd',0,0,zero(8),u32(fps*1000),u32(count*1000),u16(0x55c4),u16(0)), full('hdlr',0,0,u32(0),ascii('vide'),zero(12),ascii('shamsham\0')), minf);
    const tkhd = full('tkhd',0,7,zero(8),u32(1),u32(0),u32(duration),zero(8),u16(0),u16(0),u16(0),u16(0),matrix,u32(width*65536),u32(height*65536));
    const mvhd = full('mvhd',0,0,zero(8),u32(1000),u32(duration),u32(65536),u16(256),zero(10),matrix,zero(24),u32(2));
    return concat([ftyp, mdat, box('moov', mvhd, box('trak', tkhd, mdia))]);
  }
 // Conservative app budget, not a claimed platform limit. Base64 adds 1/3.
 const maxBytes=2500000;
 async function create(width,height,fps,bitrate){
  if(typeof root.VideoEncoder!=='function'||typeof root.VideoFrame!=='function'||typeof root.VideoEncoder.isConfigSupported!=='function')return null;
  const config={codec:'avc1.420028',width,height,bitrate:bitrate||4000000,framerate:fps,latencyMode:'realtime',avc:{format:'avc'}};
  let supported;
  try{supported=await deadline(root.VideoEncoder.isConfigSupported(config));}catch(_){return null;}
  if(!supported.supported)return null;
  const samples=[];let description=null,failure=null,total=0,index=0,encoder;
  function check(){if(failure)throw failure;}
  function close(){if(encoder&&encoder.state!=='closed')encoder.close();}
  try{
   encoder=new root.VideoEncoder({
    output(chunk,metadata){
     if(failure)return;
     try{
      if(samples.length&&chunk.timestamp<samples[samples.length-1].timestamp)throw Error('视频编码顺序异常，请重试');
      total+=chunk.byteLength;
      if(total>maxBytes)throw sizeError();
      const data=new Uint8Array(chunk.byteLength);chunk.copyTo(data);
      samples.push({data,key:chunk.type==='key',timestamp:chunk.timestamp});
      const config=metadata&&metadata.decoderConfig;
      if(config&&config.description){const d=config.description;description=new Uint8Array(d.buffer||d,d.byteOffset||0,d.byteLength).slice();}
     }catch(error){failure=error;}
    },error(error){failure=error;}
   });
   encoder.configure(config);
  }catch(_){close();return null;}
  return {
   async encode(canvas){
    check();const start=Math.round(index*1000000/fps),end=Math.round((index+1)*1000000/fps);
    const frame=new root.VideoFrame(canvas,{timestamp:start,duration:end-start});
    try{encoder.encode(frame,{keyFrame:index===0});index++;}finally{frame.close();}
    if(encoder.encodeQueueSize>3)await deadline(encoder.flush());
    check();
   },
   async finish(){
    try{
     await deadline(encoder.flush());check();
     if(!description||samples.length!==index||!samples.length||!samples[0].key)throw Error('视频编码不完整，请重试');
     return new Blob([mux(samples,width,height,fps,description)],{type:'video/mp4'});
    }finally{close();}
   },close
  };
 }
 function sizeError(){const error=Error('生成的视频过大，正在压缩');error.code='SOUR_MEDIA_TOO_LARGE';return error;}
 function deadline(promise){return new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('视频压缩超时，请重试')),15000);Promise.resolve(promise).then(value=>{clearTimeout(timer);resolve(value);},error=>{clearTimeout(timer);reject(error);});});}
 root.SourCompress={create,maxBytes,sizeError};
})(window);
