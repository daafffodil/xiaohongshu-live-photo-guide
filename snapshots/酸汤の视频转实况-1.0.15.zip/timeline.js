(function(){
 'use strict';
 const panel=document.querySelector('#trim'),rail=document.querySelector('#trim-rail'),input=document.querySelector('#trim-start'),strip=document.querySelector('#trim-strip'),label=document.querySelector('#trim-time');
 let duration=0,change=null;
 function update(){
  const start=Number(input.value)||0,length=Math.min(3,duration);
  label.textContent=start.toFixed(1)+'–'+(start+length).toFixed(1)+' 秒';
  input.setAttribute('aria-valuetext',label.textContent);
  rail.style.setProperty('--selection-width',Math.max(12,rail.getBoundingClientRect().width*length/duration)+'px');
 }
 input.addEventListener('input',()=>{update();if(change)change(Number(input.value));});
 window.addEventListener('resize',()=>{if(!panel.hidden)update();});
 window.SourTimeline={
  connect(callback){change=callback;},
  async setSource(seconds,draw){
   duration=seconds;input.value='0';input.max=String(Math.max(0,seconds-3));panel.hidden=seconds<=3;
   if(window.SourLayout)window.SourLayout.fit();
   if(panel.hidden)return;
   const context=strip.getContext('2d');context.clearRect(0,0,strip.width,strip.height);update();
   try{
    for(let i=0;i<8;i++){
     const frame=await draw(Math.min(seconds-.01,seconds*(i+.5)/8));
     const width=frame.width,height=frame.height,scale=Math.max(80/width,72/height);
     context.save();context.beginPath();context.rect(i*80,0,80,72);context.clip();
     context.drawImage(frame,i*80+(80-width*scale)/2,(72-height*scale)/2,width*scale,height*scale);context.restore();
    }
   }catch(error){console.warn('片段缩略图不可用',error);}
   finally{await draw(0);update();}
  }
 };
})();
