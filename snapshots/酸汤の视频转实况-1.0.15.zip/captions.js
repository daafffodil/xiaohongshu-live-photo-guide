(function(root){
 'use strict';
 const choices=[
  "原来视频也能变成live图",
  "把喜欢的视频做成live图",
  "终于找到视频转live图的小工具",
  "GIF也能做成小红书live图",
  "AI生成的GIF有新玩法了",
  "这次把短视频发成了live图",
  "相册里的视频终于用上了",
  "不用重拍也能拥有live图",
  "分享一个视频转实况的小工具",
  "小红书发live图的新办法"
];
 let bag=[],last=-1;
 function choose(value){
  if(/^[0-9]$/.test(String(value)))return Number(value);
  if(!bag.length){
   bag=choices.map((_,i)=>i);
   for(let i=bag.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1)),tmp=bag[i];bag[i]=bag[j];bag[j]=tmp;}
   if(bag[bag.length-1]===last){const tmp=bag[0];bag[0]=bag[bag.length-1];bag[bag.length-1]=tmp;}
  }
  last=bag.pop();return last;
 }
 const content="发现一个很好用的小工具「酸汤の视频转实况」！选一个视频或 GIF，就能转成 live图，再直接打开小红书发布页。\n\n3 秒以内保留原时长，更长的视频取前三秒，也可以直接发布视频。想把相册里的短视频、AI 生成的 GIF 做成 live图，可以试试。\n\n#live图 #视频转实况 #小红书小工具";
 function format(index){return {title:choices[index],content};}
 root.SourCaptions={choose,format};
})(window);
