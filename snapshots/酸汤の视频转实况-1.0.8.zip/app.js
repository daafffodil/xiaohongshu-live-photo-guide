'use strict';
const $=s=>document.querySelector(s),canvas=$('#preview'),ctx=canvas.getContext('2d');
let source=null,sourceURL=null,playing=!matchMedia('(prefers-reduced-motion: reduce)').matches,busy=false,epoch=performance.now(),loading=0,outputs=[];
const status=t=>{$('#status').textContent=t;};
let preparedLive=null;
function invalidateLive(){preparedLive=null;$('#publish').textContent='生成live图并发布';}
function prepareStep(action,ms,message){return new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error(message)),ms);Promise.resolve().then(action).then(value=>{clearTimeout(timer);resolve(value);},error=>{clearTimeout(timer);reject(error);});});}
const pause=()=>{$('#play').textContent=playing?'暂停':'播放';$('#play').setAttribute('aria-label',playing?'暂停预览':'播放预览');};
function trim(){const duration=(source && source.duration)||3,length=Math.min(Number($('#length').value),duration);return {start:Number($('#start').value),length};}
function sync(){const settings=document.querySelector('.settings');if(settings)settings.hidden=!!source&&source.duration<=3;const {length}=trim();$('#start').max=Math.max(0,((source && source.duration)||3)-length);$('#start').disabled=busy||Number($('#start').max)===0;$('#start-label').textContent=Number($('#start').value).toFixed(1)+' 秒';epoch=performance.now();}
function crop(image,w,h){const width=canvas.width,height=canvas.height;ctx.fillStyle='#111';ctx.fillRect(0,0,width,height);ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';const scale=Math.max(width/w,height/h);ctx.drawImage(image,(width-w*scale)/2,(height-h*scale)/2,w*scale,h*scale);}
function outputSize(media){const width=media.width||(media.video&&media.video.videoWidth)||1080,height=media.height||(media.video&&media.video.videoHeight)||1440;const unit=Math.max(1,Math.floor(Math.min(1080,width,height*3/4)/6));return {width:unit*6,height:unit*8};}
function gifSource(gif){
 const surface=document.createElement('canvas');surface.width=gif.width;surface.height=gif.height;const c=surface.getContext('2d'),patch=document.createElement('canvas');let index=-1,saved=null;
 function clear(frame){if(frame.transparent>=0)c.clearRect(frame.x,frame.y,frame.w,frame.h);else {c.fillStyle=`rgb(${gif.background.join(',')})`;c.fillRect(frame.x,frame.y,frame.w,frame.h);}}
 return {width:gif.width,height:gif.height,duration:gif.duration/1000,draw(t){const ms=Math.min(t*1000,gif.duration-1);let target=gif.frames.findIndex(f=>ms<f.start+f.delay);if(target<0)target=gif.frames.length-1;
  if(target<index){c.clearRect(0,0,gif.width,gif.height);index=-1;saved=null;}
  while(index<target){if(index>=0){const previous=gif.frames[index];if(previous.disposal===2)clear(previous);if(previous.disposal===3&&saved)c.putImageData(saved,0,0);}
   const f=gif.frames[++index];saved=f.disposal===3?c.getImageData(0,0,gif.width,gif.height):null;patch.width=f.w;patch.height=f.h;patch.getContext('2d').putImageData(new ImageData(f.rgba,f.w,f.h),0,0);c.drawImage(patch,f.x,f.y);}
  crop(surface,gif.width,gif.height);
 }};
}
function waitEvent(el,name,action){return new Promise((resolve,reject)=>{const timer=setTimeout(()=>done(Error('视频读取超时，请重试')),15000);function done(error){clearTimeout(timer);el.removeEventListener(name,ok);el.removeEventListener('error',fail);error?reject(error):resolve();}const ok=()=>done(),fail=()=>done(Error('无法读取视频，请使用可播放的MP4'));el.addEventListener(name,ok,{once:true});el.addEventListener('error',fail,{once:true});try{action();}catch(e){done(e);}});}
async function seek(video,t){if(Math.abs(video.currentTime-t)<.001&&video.readyState>=2)return;await waitEvent(video,'seeked',()=>video.currentTime=t);}
async function load(file){
 if(busy){status('正在处理素材，请稍候');return;}invalidateLive();const id=++loading;busy=true;lock();status('正在读取');let url=null,draftVideo=null,draftMedia=null;
 try{
  if(file.size>80*1024*1024)throw Error('请选择小于80MB的素材');
  let next;if(file.type==='image/gif'||/\.gif$/i.test(file.name)){next=gifSource(SourGif.decode(await prepareStep(()=>new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error('素材读取失败'));reader.readAsArrayBuffer(file);}),15000,'GIF读取超时，请重新选择')));}
  else if(/^video\//i.test(file.type)||/\.(mp4|mov|m4v)$/i.test(file.name)){
   const video=document.createElement('video');draftVideo=video;
   video.className='source-video';video.muted=true;video.defaultMuted=true;video.playsInline=true;video.preload='auto';
   video.setAttribute('playsinline','');video.setAttribute('webkit-playsinline','');video.setAttribute('aria-hidden','true');
   $('#drop').appendChild(video);
   status('正在读取视频');
   // Match the photo tool: read the selected File before calling storage APIs.
   // Only containers that reject local object URLs need a native-file fallback.
   try{
    url=URL.createObjectURL(file);
    await waitEvent(video,'loadeddata',()=>{video.src=url;video.load();});
   }catch(error){
    video.removeAttribute('src');video.load();
    if(url){URL.revokeObjectURL(url);url=null;}
    if(!window.SourBridge||!SourBridge.available()||typeof SourBridge.importVideo!=='function')throw error;
    status('正在重新读取视频');draftMedia=await SourBridge.importVideo(file);
    await waitEvent(video,'loadeddata',()=>{video.src=draftMedia.filePath;video.load();});
   }
   if(!Number.isFinite(video.duration)||video.duration<=0||!(video.videoWidth>0&&video.videoHeight>0))throw Error('无法读取视频画面，请换一个视频');
   const media=draftMedia;
   next={duration:video.duration,video,dispose(){video.pause();video.removeAttribute('src');video.load();video.remove();if(media&&typeof SourBridge.releaseVideo==='function')SourBridge.releaseVideo(media);},draw(){if(video.readyState>=2)crop(video,video.videoWidth,video.videoHeight);}};
  }
  else throw Error('请选择MP4或GIF');
  if(id!==loading)return;if(source&&source.dispose)source.dispose();else if(source&&source.video){source.video.pause();source.video.removeAttribute('src');source.video.load();}if(sourceURL)URL.revokeObjectURL(sourceURL);sourceURL=url;url=null;source=next;draftVideo=null;draftMedia=null;$('#start').value=0;clearResult();sync();if(source.video)await seek(source.video,0);source.draw(0);status(source.video?'视频已载入':'GIF已载入');
 }catch(e){status(e.message||e.errMsg||'视频读取失败，请重新选择');}finally{if(draftVideo){draftVideo.pause();draftVideo.removeAttribute('src');draftVideo.load();draftVideo.remove();}if(draftMedia&&typeof SourBridge.releaseVideo==='function')SourBridge.releaseVideo(draftMedia);if(url)URL.revokeObjectURL(url);busy=false;lock();}
}
function clearResult(){invalidateLive();}
function lock(){for(const id of ['file','gif-file','length','play','publish','publish-video']){const input=$('#'+id);if(input)input.disabled=busy;}$('#start').disabled=busy||Number($('#start').max)===0;}
async function build(){
 if(!window.ShamMp4)throw Error('视频组件未加载，请重新打开小工具');
 const {start,length}=trim(),size=outputSize(source),width=size.width,height=size.height,count=Math.max(1,Math.ceil(length*12)),fps=count/length,samples=[],encoder=ShamMp4.createEncoder(width,height);let cover;
 const previewWidth=canvas.width,previewHeight=canvas.height;canvas.width=width;canvas.height=height;
 try{
 if(source.video)source.video.pause();
 for(let i=0;i<count;i++){const t=Math.min(start+i/fps,source.duration-.001);if(source.video)await seek(source.video,t);source.draw(t);if(i===0)cover=canvas.toDataURL('image/jpeg',.97);samples.push(encoder.encode(ctx.getImageData(0,0,width,height).data));status('正在生成 '+Math.round((i+1)/count*100)+'%');await new Promise(r=>setTimeout(r,0));}
 return {cover,video:new Blob([ShamMp4.mux(samples,width,height,fps,true)],{type:'video/mp4'})};
 }finally{canvas.width=previewWidth;canvas.height=previewHeight;source.draw(trim().start);}
}
async function publishNative(mode){
 if(busy){status('正在处理素材，请稍候');return;}
 if(!source){status('请先选择视频或GIF');return;}
 if(!window.SourBridge||!SourBridge.available()){status('当前环境不支持发布，请在小红书内打开或更新客户端');return;}
 const videoMode=mode==='video',button=$(videoMode?'#publish-video':'#publish');
 busy=true;lock();let action='生成素材';
 try{
  if(!preparedLive){
   button.textContent=videoMode?'正在生成视频':'正在生成live图';status('正在准备素材');
   await prepareStep(()=>SourBridge.validate(),10000,'客户端检查超时，请重新打开小工具');
   const result=await build();
   preparedLive=await SourBridge.prepare(result.cover,result.video,status);
  }
  action=videoMode?'发布视频':'发布live图';button.textContent='正在打开发布页';status(videoMode?'正在打开视频发布页':'正在打开live图发布页');
  if(videoMode)await SourBridge.publishVideoPrepared(preparedLive);
  else await SourBridge.publishPrepared(preparedLive);
  status('已返回小工具，请在小红书查看笔记状态');
 }catch(e){
  const message=String(e&&(e.errMsg||e.message)||'');
  if(/file[\s_-]*not[\s_-]*found|enoent|文件不存在|找不到文件/i.test(message))invalidateLive();
  status(SourBridge.errorMessage?SourBridge.errorMessage(e,action):(e.message||e.errMsg||'生成失败，请重试'));
 }
 finally{busy=false;epoch=performance.now();lock();$('#publish').textContent=preparedLive?'发布live图':'生成live图并发布';$('#publish-video').textContent='发布视频';}
}
async function generate(publish,mode='live'){
 return publishNative(mode);
}
function frame(now){if(source&&!busy&&playing&&!document.hidden){const {start,length}=trim(),t=start+((now-epoch)/1000%length);if(source.video){if(source.video.paused){source.video.currentTime=t;source.video.play().catch(()=>{});}if(source.video.currentTime>=start+length||source.video.currentTime<start)source.video.currentTime=t;}source.draw(t);}requestAnimationFrame(frame);}
for(const id of ['file','gif-file'])$('#'+id).addEventListener('change',async e=>{const input=e.currentTarget,file=input.files&&input.files[0];if(!file)return;try{await load(file);}finally{input.value='';}});
$('#play').addEventListener('click',()=>{playing=!playing;if((source && source.video))source.video.pause();epoch=performance.now();pause();});
for(const id of ['start','length'])$('#'+id).addEventListener('input',()=>{sync();clearResult();if(source){const t=trim().start;if(source.video)seek(source.video,t).then(()=>source.draw(t)).catch(e=>status(e.message));else source.draw(t);}});
if(window.SourPublishEntry)SourPublishEntry.connect(mode=>generate(true,mode));else {$('#publish').addEventListener('click',()=>generate(true,'live'));$('#publish-video').addEventListener('click',()=>generate(true,'video'));}
for(const event of ['dragover','dragleave','drop'])$('#drop').addEventListener(event,e=>{e.preventDefault();$('#drop').classList.toggle('drag',event==='dragover');if(event==='drop'&&e.dataTransfer.files[0])load(e.dataTransfer.files[0]);});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&(source && source.video))source.video.pause();});
document.addEventListener('gesturestart',e=>e.preventDefault(),{passive:false});

pause();requestAnimationFrame(frame);

if(window.SourDemo){source=window.SourDemo.create(canvas);sync();source.draw(0);}

async function fitHeader(){
 const sdk=window.xhs&&window.xhs.miniTool;
 if(!sdk||typeof sdk.getWindowInfo!=='function')return;
 try{const info=await sdk.getWindowInfo();let top=Number(info.safeArea&&info.safeArea.top)||0;const buttons=info.menuButtons||{};['back','me','share'].forEach(name=>{if(buttons[name])top=Math.max(top,Number(buttons[name].bottom)||0);});document.documentElement.style.setProperty('--header-top-space',Math.ceil(top+16)+'px');}catch(e){}
}
fitHeader();window.addEventListener('resize',fitHeader);
