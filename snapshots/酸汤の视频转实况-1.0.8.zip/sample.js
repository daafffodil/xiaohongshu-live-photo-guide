(function(root){
 'use strict';
 root.SourDemo={create(canvas){
  const c=canvas.getContext('2d');
  function ellipse(x,y,rx,ry,color,angle){c.fillStyle=color;c.beginPath();c.ellipse(x,y,rx,ry,angle||0,0,Math.PI*2);c.fill();}
  function line(points,color,width){c.strokeStyle=color;c.lineWidth=width;c.lineCap='round';c.beginPath();c.moveTo(points[0],points[1]);for(let i=2;i<points.length;i+=2)c.lineTo(points[i],points[i+1]);c.stroke();}
  return {width:1080,height:1440,duration:3,draw(t){
   const phase=t/3*Math.PI*2,sway=Math.sin(phase)*.045;
   c.save();c.scale(canvas.width/1080,canvas.height/1440);
   c.fillStyle='#e9e5d9';c.fillRect(0,0,1080,1440);
   c.fillStyle='#28527a';c.fillRect(100,100,880,990);
   c.fillStyle='#c5d8da';c.fillRect(126,126,828,938);
   ellipse(738,345,132,132,'#f3ad53');
   c.fillStyle='#8b9b74';c.beginPath();c.moveTo(126,850);c.bezierCurveTo(370,690,580,720,954,860);c.lineTo(954,1064);c.lineTo(126,1064);c.fill();
   c.fillStyle='#547966';c.beginPath();c.moveTo(126,962);c.bezierCurveTo(480,810,690,900,954,790);c.lineTo(954,1064);c.lineTo(126,1064);c.fill();
   c.fillStyle='#e9e5d9';c.fillRect(524,126,26,938);c.fillRect(126,646,828,24);
   c.fillStyle='#28527a';c.fillRect(80,1080,920,36);
   c.fillStyle='#c07758';c.fillRect(0,1200,1080,240);
   for(let x=0;x<1080;x+=90){c.fillStyle=(x/90)%2?'#cf906b':'#daab83';c.fillRect(x,1240,90,26);c.fillRect(x,1350,90,26);}
   ellipse(543,1230,227,27,'#966149');
   c.save();c.translate(540,1030);c.rotate(sway);
   line([0,60,-6,-440],'#274b3b',13);
   for(let i=0;i<5;i++){const y=-90-i*79,side=i%2?1:-1;line([-3,y,side*105,y-57],'#274b3b',7);ellipse(side*126,y-75,84,34,i%2?'#466c48':'#64834d',side*-.48);line([side*55,y-25,side*177,y-98],'#d2c38a',2);}
   c.restore();
   c.fillStyle='#f2d290';c.beginPath();c.moveTo(390,1035);c.lineTo(690,1035);c.lineTo(657,1215);c.quadraticCurveTo(540,1250,423,1215);c.closePath();c.fill();
   for(let x=430;x<=650;x+=27)line([x,1070,x+(540-x)*.11,1195],'#bd925b',3);
   ellipse(540,1040,153,25,'#e5bb74');ellipse(540,1036,127,14,'#604f35');
   const bx=267+Math.sin(phase)*38,by=398+Math.cos(phase)*12;
   line([bx-28,by+8,bx,by-6,bx+28,by+8],'#28527a',5);
   c.restore();
  }};
 }};
})(window);
